﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBaseProject
{
	public partial class Login : Form
	{
		public Login()
		{
			InitializeComponent();
		}

		SqlConnection connection = MySqlConnection.MySqlConnection.Conn();

		private void register_linklabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form1 register = new Form1();
			register.Show();
			this.Close();

		}

		private void login_btn_Click(object sender, EventArgs e)
		{
			String username = username_txt.Text;
			String password = password_txt.Text;

			try
			{
				int userId = 0;  // Initialize userId to 0

				// Construct the SELECT query to retrieve the user ID from the Student table
				string selectStudentQuery = "SELECT id FROM Student WHERE username = @username AND password = @password";

				// Create a SqlCommand object with the SELECT query and connection
				using (SqlCommand command = new SqlCommand(selectStudentQuery, connection))
				{
					// Add parameters to the command to prevent SQL injection
					command.Parameters.AddWithValue("@username", username);
					command.Parameters.AddWithValue("@password", password);

					// Open the connection and execute the SELECT query
					connection.Open();
					object studentResult = command.ExecuteScalar();

					if (studentResult != null)  // User found in Student table
					{
						userId = Convert.ToInt32(studentResult);
						GlobalVariables.currentUserId = userId;
						GlobalVariables.isAdmin = false;
						MessageBox.Show($"Student {userId} Login Success");

						Home home = new Home();
						home.Show();
						this.Close();
					}
				}

				if (userId == 0)  // If user not found in Student table, check Admin table
				{
					// Construct the SELECT query to retrieve the user ID from the Admin table
					string selectAdminQuery = "SELECT id FROM Admin WHERE username = @username AND password = @password";

					// Create a new SqlCommand object with the SELECT query and connection
					using (SqlCommand command = new SqlCommand(selectAdminQuery, connection))
					{
						// Add parameters to the command to prevent SQL injection
						command.Parameters.AddWithValue("@username", username);
						command.Parameters.AddWithValue("@password", password);

						// Execute the SELECT query
						object adminResult = command.ExecuteScalar();

						if (adminResult != null)  // User found in Admin table
						{
							userId = Convert.ToInt32(adminResult);
							GlobalVariables.currentUserId = userId;
							GlobalVariables.isAdmin = true;
							MessageBox.Show($"Admin {userId} Login Success");

							Home home = new Home();
							home.Show();
							this.Close();
						}
						else  // User not found in either table
						{
							MessageBox.Show("Invalid Login Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				connection.Close();
			}
		}


	}
}
