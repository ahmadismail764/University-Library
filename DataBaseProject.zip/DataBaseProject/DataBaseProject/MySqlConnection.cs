﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseProject.MySqlConnection
{
	public class MySqlConnection
	{
		public MySqlConnection()
		{
		}

		public static SqlConnection Conn()
		{
			return
				new
				SqlConnection(
					@"Data Source=DESKTOP-3S2SUUL\SQLEXPRESS;Initial Catalog=UniLibrary;Integrated Security=True;");

		}
	}
}
