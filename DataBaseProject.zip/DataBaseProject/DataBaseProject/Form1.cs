using System.Data.SqlClient;

namespace DataBaseProject
{
	public partial class Form1 : Form
	{
		SqlConnection connection = MySqlConnection.MySqlConnection.Conn();
		public Form1()
		{
			InitializeComponent();
		}

		private void register_btn_Click(object sender, EventArgs e)
		{
			String username = username_txt.Text;
			String password = password_txt.Text;
			String email = email_txt.Text;
			String phone = phone_txt.Text;
			String address = address_txt.Text;
			bool isAdmin = admin_radbtn.Checked;

			try
			{
				// Construct the INSERT query
				String insertQuery = isAdmin ? "INSERT INTO Admin (username, email, password, phone, address) OUTPUT INSERTED.id VALUES (@username, @email, @password, @phone, @address)" :
											  "INSERT INTO Student (username, email, password, phone, address) OUTPUT INSERTED.id VALUES (@username, @email, @password, @phone, @address)";


				// Create a SqlCommand object with the INSERT query and connection
				using (SqlCommand command = new SqlCommand(insertQuery, connection))
				{
					// Add parameters to the command to prevent SQL injection
					command.Parameters.AddWithValue("@username", username);
					command.Parameters.AddWithValue("@email", email);
					command.Parameters.AddWithValue("@password", password);
					command.Parameters.AddWithValue("@phone", phone);
					command.Parameters.AddWithValue("@address", address);

					// Open the connection and execute the INSERT query
					connection.Open();

					// Get the ID of the inserted record
					int insertedId = -1;
					insertedId = Convert.ToInt32(command.ExecuteScalar());

					if (insertedId != -1)
					{
						GlobalVariables.isAdmin = isAdmin;
						GlobalVariables.currentUserId = insertedId;
						MessageBox.Show("Registration Successful: " + GlobalVariables.currentUserId);
						Home home = new Home();
						home.Show();
						this.Hide();
					}
					else
					{
						MessageBox.Show("Registration Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				connection.Close();
			}
		}

		private void signIn_linklabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Login login = new Login();
			login.Show();
			this.Hide();
		}
	}
}