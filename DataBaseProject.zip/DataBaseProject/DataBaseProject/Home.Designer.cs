﻿namespace DataBaseProject
{
	partial class Home
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			update_btn = new Button();
			brows_btn = new Button();
			add_btn = new Button();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label1.Location = new Point(239, 54);
			label1.Name = "label1";
			label1.Size = new Size(455, 32);
			label1.TabIndex = 0;
			label1.Text = "Welcome To UNI Library System";
			// 
			// update_btn
			// 
			update_btn.Location = new Point(344, 135);
			update_btn.Name = "update_btn";
			update_btn.Size = new Size(223, 45);
			update_btn.TabIndex = 1;
			update_btn.Text = "Update User Details";
			update_btn.UseVisualStyleBackColor = true;
			update_btn.Click += update_btn_Click;
			// 
			// brows_btn
			// 
			brows_btn.Location = new Point(344, 210);
			brows_btn.Name = "brows_btn";
			brows_btn.Size = new Size(223, 45);
			brows_btn.TabIndex = 1;
			brows_btn.Text = "Browse Books";
			brows_btn.UseVisualStyleBackColor = true;
			brows_btn.Click += brows_btn_Click;
			// 
			// add_btn
			// 
			add_btn.Location = new Point(344, 292);
			add_btn.Name = "add_btn";
			add_btn.Size = new Size(223, 45);
			add_btn.TabIndex = 1;
			add_btn.Text = "Add Book";
			add_btn.UseVisualStyleBackColor = true;
			// 
			// Home
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(936, 593);
			Controls.Add(add_btn);
			Controls.Add(brows_btn);
			Controls.Add(update_btn);
			Controls.Add(label1);
			Name = "Home";
			Text = "Home";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Button update_btn;
		private Button brows_btn;
		private Button add_btn;
	}
}