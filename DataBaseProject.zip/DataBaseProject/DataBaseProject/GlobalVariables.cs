﻿namespace DataBaseProject
{
	internal class GlobalVariables
	{
		public static int currentUserId { get; set; }
		public static bool isAdmin { get; set; }
		public static List<Book> books = new List<Book>();
	}
}
