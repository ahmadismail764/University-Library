﻿namespace DataBaseProject
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			username_label = new Label();
			password_label = new Label();
			email_label = new Label();
			phone_label = new Label();
			address_label = new Label();
			username_txt = new TextBox();
			password_txt = new TextBox();
			phone_txt = new TextBox();
			address_txt = new TextBox();
			email_txt = new TextBox();
			label1 = new Label();
			admin_radbtn = new RadioButton();
			student_radbtn = new RadioButton();
			register_btn = new Button();
			signIn_linklabel = new LinkLabel();
			SuspendLayout();
			// 
			// username_label
			// 
			username_label.AutoSize = true;
			username_label.Location = new Point(213, 114);
			username_label.Name = "username_label";
			username_label.Size = new Size(75, 20);
			username_label.TabIndex = 0;
			username_label.Text = "Username";
			// 
			// password_label
			// 
			password_label.AutoSize = true;
			password_label.Location = new Point(211, 170);
			password_label.Name = "password_label";
			password_label.Size = new Size(70, 20);
			password_label.TabIndex = 1;
			password_label.Text = "Password";
			// 
			// email_label
			// 
			email_label.AutoSize = true;
			email_label.Location = new Point(230, 228);
			email_label.Name = "email_label";
			email_label.Size = new Size(46, 20);
			email_label.TabIndex = 1;
			email_label.Text = "Email";
			// 
			// phone_label
			// 
			phone_label.AutoSize = true;
			phone_label.Location = new Point(227, 281);
			phone_label.Name = "phone_label";
			phone_label.Size = new Size(50, 20);
			phone_label.TabIndex = 1;
			phone_label.Text = "Phone";
			phone_label.TextAlign = ContentAlignment.TopCenter;
			// 
			// address_label
			// 
			address_label.AutoSize = true;
			address_label.Location = new Point(215, 335);
			address_label.Name = "address_label";
			address_label.Size = new Size(62, 20);
			address_label.TabIndex = 1;
			address_label.Text = "Address";
			// 
			// username_txt
			// 
			username_txt.Location = new Point(298, 113);
			username_txt.Name = "username_txt";
			username_txt.Size = new Size(263, 27);
			username_txt.TabIndex = 2;
			// 
			// password_txt
			// 
			password_txt.Location = new Point(298, 169);
			password_txt.Name = "password_txt";
			password_txt.Size = new Size(263, 27);
			password_txt.TabIndex = 2;
			// 
			// phone_txt
			// 
			phone_txt.Location = new Point(298, 276);
			phone_txt.Name = "phone_txt";
			phone_txt.Size = new Size(263, 27);
			phone_txt.TabIndex = 2;
			// 
			// address_txt
			// 
			address_txt.Location = new Point(298, 334);
			address_txt.Name = "address_txt";
			address_txt.Size = new Size(263, 27);
			address_txt.TabIndex = 2;
			// 
			// email_txt
			// 
			email_txt.Location = new Point(298, 224);
			email_txt.Name = "email_txt";
			email_txt.Size = new Size(263, 27);
			email_txt.TabIndex = 3;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label1.Location = new Point(339, 32);
			label1.Name = "label1";
			label1.Size = new Size(131, 32);
			label1.TabIndex = 4;
			label1.Text = "Register";
			// 
			// admin_radbtn
			// 
			admin_radbtn.AutoSize = true;
			admin_radbtn.Location = new Point(330, 407);
			admin_radbtn.Name = "admin_radbtn";
			admin_radbtn.Size = new Size(74, 24);
			admin_radbtn.TabIndex = 5;
			admin_radbtn.TabStop = true;
			admin_radbtn.Text = "Admin";
			admin_radbtn.UseVisualStyleBackColor = true;
			// 
			// student_radbtn
			// 
			student_radbtn.AutoSize = true;
			student_radbtn.Location = new Point(431, 406);
			student_radbtn.Name = "student_radbtn";
			student_radbtn.Size = new Size(81, 24);
			student_radbtn.TabIndex = 5;
			student_radbtn.TabStop = true;
			student_radbtn.Text = "Student";
			student_radbtn.UseVisualStyleBackColor = true;
			// 
			// register_btn
			// 
			register_btn.Location = new Point(251, 494);
			register_btn.Name = "register_btn";
			register_btn.Size = new Size(136, 43);
			register_btn.TabIndex = 6;
			register_btn.Text = "Register";
			register_btn.UseVisualStyleBackColor = true;
			register_btn.Click += register_btn_Click;
			// 
			// signIn_linklabel
			// 
			signIn_linklabel.AutoSize = true;
			signIn_linklabel.Location = new Point(407, 505);
			signIn_linklabel.Name = "signIn_linklabel";
			signIn_linklabel.Size = new Size(227, 20);
			signIn_linklabel.TabIndex = 7;
			signIn_linklabel.TabStop = true;
			signIn_linklabel.Text = "Already have an account? Sign In";
			signIn_linklabel.LinkClicked += signIn_linklabel_LinkClicked;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 599);
			Controls.Add(signIn_linklabel);
			Controls.Add(register_btn);
			Controls.Add(student_radbtn);
			Controls.Add(admin_radbtn);
			Controls.Add(label1);
			Controls.Add(email_txt);
			Controls.Add(address_txt);
			Controls.Add(phone_txt);
			Controls.Add(password_txt);
			Controls.Add(username_txt);
			Controls.Add(address_label);
			Controls.Add(phone_label);
			Controls.Add(email_label);
			Controls.Add(password_label);
			Controls.Add(username_label);
			Name = "Form1";
			Text = "Register";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label username_label;
		private Label password_label;
		private Label email_label;
		private Label phone_label;
		private Label address_label;
		private TextBox username_txt;
		private TextBox password_txt;
		private TextBox phone_txt;
		private TextBox address_txt;
		private TextBox email_txt;
		private Label label1;
		private RadioButton admin_radbtn;
		private RadioButton student_radbtn;
		private Button register_btn;
		private LinkLabel signIn_linklabel;
	}
}