﻿namespace DataBaseProject
{
    partial class UpdateUserDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            update_btn = new Button();
            label1 = new Label();
            email_txt = new TextBox();
            address_txt = new TextBox();
            phone_txt = new TextBox();
            password_txt = new TextBox();
            username_txt = new TextBox();
            address_label = new Label();
            phone_label = new Label();
            email_label = new Label();
            password_label = new Label();
            username_label = new Label();
            SuspendLayout();
            // 
            // update_btn
            // 
            update_btn.Location = new Point(441, 441);
            update_btn.Name = "update_btn";
            update_btn.Size = new Size(136, 43);
            update_btn.TabIndex = 21;
            update_btn.Text = "update";
            update_btn.UseVisualStyleBackColor = true;
            update_btn.Click += update_btn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(353, 51);
            label1.Name = "label1";
            label1.Size = new Size(290, 32);
            label1.TabIndex = 18;
            label1.Text = "Update User Details";
            // 
            // email_txt
            // 
            email_txt.Location = new Point(400, 242);
            email_txt.Name = "email_txt";
            email_txt.Size = new Size(263, 27);
            email_txt.TabIndex = 17;
            // 
            // address_txt
            // 
            address_txt.Location = new Point(400, 352);
            address_txt.Name = "address_txt";
            address_txt.Size = new Size(263, 27);
            address_txt.TabIndex = 13;
            // 
            // phone_txt
            // 
            phone_txt.Location = new Point(400, 294);
            phone_txt.Name = "phone_txt";
            phone_txt.Size = new Size(263, 27);
            phone_txt.TabIndex = 14;
            // 
            // password_txt
            // 
            password_txt.Location = new Point(400, 187);
            password_txt.Name = "password_txt";
            password_txt.Size = new Size(263, 27);
            password_txt.TabIndex = 15;
            // 
            // username_txt
            // 
            username_txt.Location = new Point(400, 131);
            username_txt.Name = "username_txt";
            username_txt.Size = new Size(263, 27);
            username_txt.TabIndex = 16;
            // 
            // address_label
            // 
            address_label.AutoSize = true;
            address_label.Location = new Point(317, 353);
            address_label.Name = "address_label";
            address_label.Size = new Size(62, 20);
            address_label.TabIndex = 9;
            address_label.Text = "Address";
            // 
            // phone_label
            // 
            phone_label.AutoSize = true;
            phone_label.Location = new Point(329, 299);
            phone_label.Name = "phone_label";
            phone_label.Size = new Size(50, 20);
            phone_label.TabIndex = 10;
            phone_label.Text = "Phone";
            phone_label.TextAlign = ContentAlignment.TopCenter;
            // 
            // email_label
            // 
            email_label.AutoSize = true;
            email_label.Location = new Point(332, 246);
            email_label.Name = "email_label";
            email_label.Size = new Size(46, 20);
            email_label.TabIndex = 11;
            email_label.Text = "Email";
            // 
            // password_label
            // 
            password_label.AutoSize = true;
            password_label.Location = new Point(313, 188);
            password_label.Name = "password_label";
            password_label.Size = new Size(70, 20);
            password_label.TabIndex = 12;
            password_label.Text = "Password";
            // 
            // username_label
            // 
            username_label.AutoSize = true;
            username_label.Location = new Point(315, 132);
            username_label.Name = "username_label";
            username_label.Size = new Size(75, 20);
            username_label.TabIndex = 8;
            username_label.Text = "Username";
            // 
            // UpdateUserDetails
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1049, 604);
            Controls.Add(update_btn);
            Controls.Add(label1);
            Controls.Add(email_txt);
            Controls.Add(address_txt);
            Controls.Add(phone_txt);
            Controls.Add(password_txt);
            Controls.Add(username_txt);
            Controls.Add(address_label);
            Controls.Add(phone_label);
            Controls.Add(email_label);
            Controls.Add(password_label);
            Controls.Add(username_label);
            Name = "UpdateUserDetails";
            Text = "UpdateUserDetails";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button update_btn;
        private Label label1;
        private TextBox email_txt;
        private TextBox address_txt;
        private TextBox phone_txt;
        private TextBox password_txt;
        private TextBox username_txt;
        private Label address_label;
        private Label phone_label;
        private Label email_label;
        private Label password_label;
        private Label username_label;
    }
}