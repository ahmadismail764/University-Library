﻿using System.Net;

namespace DataBaseProject
{
	partial class Browse
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			listView1 = new ListView();
			Id = new ColumnHeader();
			BookName = new ColumnHeader();
			Author = new ColumnHeader();
			last = new ColumnHeader();
			view_book = new Button();
			update_book = new Button();
			label2 = new Label();
			search_btn = new Button();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label1.Location = new Point(225, 28);
			label1.Name = "label1";
			label1.Size = new Size(118, 32);
			label1.TabIndex = 0;
			label1.Text = "Browse";
			// 
			// listView1
			// 
			listView1.Columns.AddRange(new ColumnHeader[] { Id, BookName, Author, last });
			listView1.FullRowSelect = true;
			listView1.Location = new Point(12, 81);
			listView1.Name = "listView1";
			listView1.Size = new Size(552, 459);
			listView1.TabIndex = 1;
			listView1.UseCompatibleStateImageBehavior = false;
			listView1.View = View.Details;
			listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
			// 
			// Id
			// 
			Id.Text = "Id";
			Id.TextAlign = HorizontalAlignment.Center;
			Id.Width = 50;
			// 
			// BookName
			// 
			BookName.Text = "Name";
			BookName.Width = 150;
			// 
			// Author
			// 
			Author.Text = "Author";
			Author.Width = 150;
			// 
			// last
			// 
			last.Text = "";
			last.Width = 198;
			// 
			// view_book
			// 
			view_book.Location = new Point(470, 563);
			view_book.Name = "view_book";
			view_book.Size = new Size(94, 29);
			view_book.TabIndex = 2;
			view_book.Text = "View";
			view_book.UseVisualStyleBackColor = true;
			view_book.Click += view_book_Click;
			// 
			// update_book
			// 
			update_book.Location = new Point(359, 563);
			update_book.Name = "update_book";
			update_book.Size = new Size(94, 29);
			update_book.TabIndex = 3;
			update_book.Text = "Update";
			update_book.UseVisualStyleBackColor = true;
			update_book.Click += update_book_Click;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label2.Location = new Point(12, 28);
			label2.Name = "label2";
			label2.Size = new Size(46, 32);
			label2.TabIndex = 4;
			label2.Text = "🔙";
			label2.Click += label2_Click;
			// 
			// search_btn
			// 
			search_btn.Location = new Point(470, 28);
			search_btn.Name = "search_btn";
			search_btn.Size = new Size(94, 29);
			search_btn.TabIndex = 5;
			search_btn.Text = "Search";
			search_btn.UseVisualStyleBackColor = true;
			search_btn.Click += search_btn_Click;
			// 
			// Browse
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(576, 613);
			Controls.Add(search_btn);
			Controls.Add(label2);
			Controls.Add(update_book);
			Controls.Add(view_book);
			Controls.Add(listView1);
			Controls.Add(label1);
			Name = "Browse";
			Text = "Browse Books";
			Load += Browse_Books_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private ListView listView1;
		private Button view_book;
		private Button update_book;
		private Label label2;
		private ColumnHeader Id;
		private ColumnHeader BookName;
		private ColumnHeader Author;
		private ColumnHeader last;
		private Button search_btn;
	}
}