﻿namespace DataBaseProject
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            register_linklabel = new LinkLabel();
            login_label = new Label();
            password_txt = new TextBox();
            username_txt = new TextBox();
            password_label = new Label();
            username_label = new Label();
            login_btn = new Button();
            SuspendLayout();
            // 
            // register_linklabel
            // 
            register_linklabel.AutoSize = true;
            register_linklabel.Location = new Point(431, 306);
            register_linklabel.Name = "register_linklabel";
            register_linklabel.Size = new Size(144, 20);
            register_linklabel.TabIndex = 0;
            register_linklabel.TabStop = true;
            register_linklabel.Text = "Create New Account";
            register_linklabel.LinkClicked += register_linklabel_LinkClicked;
            // 
            // login_label
            // 
            login_label.AutoSize = true;
            login_label.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            login_label.Location = new Point(353, 62);
            login_label.Name = "login_label";
            login_label.Size = new Size(91, 32);
            login_label.TabIndex = 9;
            login_label.Text = "Login";
            // 
            // password_txt
            // 
            password_txt.Location = new Point(312, 199);
            password_txt.Name = "password_txt";
            password_txt.Size = new Size(263, 27);
            password_txt.TabIndex = 7;
            // 
            // username_txt
            // 
            username_txt.Location = new Point(312, 143);
            username_txt.Name = "username_txt";
            username_txt.Size = new Size(263, 27);
            username_txt.TabIndex = 8;
            // 
            // password_label
            // 
            password_label.AutoSize = true;
            password_label.Location = new Point(225, 200);
            password_label.Name = "password_label";
            password_label.Size = new Size(70, 20);
            password_label.TabIndex = 6;
            password_label.Text = "Password";
            // 
            // username_label
            // 
            username_label.AutoSize = true;
            username_label.Location = new Point(227, 144);
            username_label.Name = "username_label";
            username_label.Size = new Size(75, 20);
            username_label.TabIndex = 5;
            username_label.Text = "Username";
            // 
            // login_btn
            // 
            login_btn.Location = new Point(270, 295);
            login_btn.Name = "login_btn";
            login_btn.Size = new Size(136, 43);
            login_btn.TabIndex = 11;
            login_btn.Text = "Login";
            login_btn.UseVisualStyleBackColor = true;
            login_btn.Click += login_btn_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(login_btn);
            Controls.Add(login_label);
            Controls.Add(password_txt);
            Controls.Add(username_txt);
            Controls.Add(password_label);
            Controls.Add(username_label);
            Controls.Add(register_linklabel);
            Name = "Login";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel register_linklabel;
        private Label login_label;
        private TextBox password_txt;
        private TextBox username_txt;
        private Label password_label;
        private Label username_label;
        private Button login_btn;
    }
}