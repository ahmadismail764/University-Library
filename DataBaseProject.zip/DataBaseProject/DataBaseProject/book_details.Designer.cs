﻿namespace DataBaseProject
{
	partial class book_details
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			data_table = new TableLayoutPanel();
			fees = new Label();
			label_5 = new Label();
			catId = new Label();
			label_4 = new Label();
			ISBN = new Label();
			author = new Label();
			label_2 = new Label();
			label_1 = new Label();
			label_3 = new Label();
			Id = new Label();
			tableLayoutPanel1 = new TableLayoutPanel();
			book_name = new Label();
			data_table.SuspendLayout();
			tableLayoutPanel1.SuspendLayout();
			SuspendLayout();
			// 
			// data_table
			// 
			data_table.AllowDrop = true;
			data_table.Anchor = AnchorStyles.None;
			data_table.AutoSize = true;
			data_table.ColumnCount = 2;
			data_table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48F));
			data_table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52F));
			data_table.Controls.Add(fees, 1, 4);
			data_table.Controls.Add(label_5, 0, 4);
			data_table.Controls.Add(catId, 1, 3);
			data_table.Controls.Add(label_4, 0, 3);
			data_table.Controls.Add(ISBN, 1, 2);
			data_table.Controls.Add(author, 1, 1);
			data_table.Controls.Add(label_2, 0, 1);
			data_table.Controls.Add(label_1, 0, 0);
			data_table.Controls.Add(label_3, 0, 2);
			data_table.Controls.Add(Id, 1, 0);
			data_table.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			data_table.Location = new Point(38, 62);
			data_table.Name = "data_table";
			data_table.RowCount = 5;
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			data_table.Size = new Size(372, 338);
			data_table.TabIndex = 6;
			// 
			// fees
			// 
			fees.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			fees.AutoSize = true;
			fees.Location = new Point(181, 268);
			fees.Name = "fees";
			fees.Size = new Size(188, 70);
			fees.TabIndex = 9;
			fees.TextAlign = ContentAlignment.MiddleRight;
			// 
			// label_5
			// 
			label_5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_5.AutoSize = true;
			label_5.Location = new Point(3, 268);
			label_5.Name = "label_5";
			label_5.Size = new Size(172, 70);
			label_5.TabIndex = 8;
			label_5.Text = "Fees";
			label_5.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// catId
			// 
			catId.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			catId.AutoSize = true;
			catId.Location = new Point(181, 201);
			catId.Name = "catId";
			catId.Size = new Size(188, 67);
			catId.TabIndex = 7;
			catId.TextAlign = ContentAlignment.MiddleRight;
			// 
			// label_4
			// 
			label_4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_4.AutoSize = true;
			label_4.Location = new Point(3, 201);
			label_4.Name = "label_4";
			label_4.Size = new Size(172, 67);
			label_4.TabIndex = 6;
			label_4.Text = "Category id";
			label_4.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// ISBN
			// 
			ISBN.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			ISBN.AutoSize = true;
			ISBN.Location = new Point(181, 134);
			ISBN.Name = "ISBN";
			ISBN.Size = new Size(188, 67);
			ISBN.TabIndex = 5;
			ISBN.TextAlign = ContentAlignment.MiddleRight;
			// 
			// author
			// 
			author.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			author.AutoSize = true;
			author.Location = new Point(181, 67);
			author.Name = "author";
			author.Size = new Size(188, 67);
			author.TabIndex = 3;
			author.TextAlign = ContentAlignment.MiddleRight;
			// 
			// label_2
			// 
			label_2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_2.AutoSize = true;
			label_2.Location = new Point(3, 67);
			label_2.Name = "label_2";
			label_2.Size = new Size(172, 67);
			label_2.TabIndex = 2;
			label_2.Text = "Author";
			label_2.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label_1
			// 
			label_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_1.AutoSize = true;
			label_1.Location = new Point(3, 0);
			label_1.Name = "label_1";
			label_1.Size = new Size(172, 67);
			label_1.TabIndex = 0;
			label_1.Text = "ID";
			label_1.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label_3
			// 
			label_3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_3.AutoSize = true;
			label_3.Location = new Point(3, 134);
			label_3.Name = "label_3";
			label_3.Size = new Size(172, 67);
			label_3.TabIndex = 4;
			label_3.Text = "ISBN";
			label_3.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// Id
			// 
			Id.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			Id.AutoSize = true;
			Id.Location = new Point(181, 0);
			Id.Name = "Id";
			Id.Size = new Size(188, 67);
			Id.TabIndex = 1;
			Id.TextAlign = ContentAlignment.MiddleRight;
			// 
			// tableLayoutPanel1
			// 
			tableLayoutPanel1.AllowDrop = true;
			tableLayoutPanel1.Anchor = AnchorStyles.None;
			tableLayoutPanel1.AutoSize = true;
			tableLayoutPanel1.ColumnCount = 1;
			tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48F));
			tableLayoutPanel1.Controls.Add(book_name, 0, 0);
			tableLayoutPanel1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			tableLayoutPanel1.Location = new Point(4, -41);
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			tableLayoutPanel1.RowCount = 1;
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			tableLayoutPanel1.Size = new Size(439, 97);
			tableLayoutPanel1.TabIndex = 10;
			// 
			// book_name
			// 
			book_name.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			book_name.AutoSize = true;
			book_name.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			book_name.Location = new Point(3, 0);
			book_name.Name = "book_name";
			book_name.Size = new Size(433, 97);
			book_name.TabIndex = 1;
			book_name.TextAlign = ContentAlignment.BottomCenter;
			// 
			// book_details
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(446, 414);
			Controls.Add(tableLayoutPanel1);
			Controls.Add(data_table);
			Name = "book_details";
			Text = "book_details";
			data_table.ResumeLayout(false);
			data_table.PerformLayout();
			tableLayoutPanel1.ResumeLayout(false);
			tableLayoutPanel1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion
		private Label label_1;
		private Label fees;
		private Label label_5;
		private Label catId;
		private Label label_4;
		private Label ISBN;
		private Label label_3;
		private Label author;
		private Label label_2;
		private Label Id;
		private TableLayoutPanel tableLayoutPanel1;
		private Label book_name;
		protected TableLayoutPanel data_table;
	}
}