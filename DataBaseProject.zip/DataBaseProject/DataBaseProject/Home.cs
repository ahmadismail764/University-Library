﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBaseProject
{
	public partial class Home : Form
	{

		bool isAdmin = GlobalVariables.isAdmin;

		public Home()
		{
			InitializeComponent();

			if (isAdmin)
			{
				add_btn.Visible = true;
			}
			else
			{
				add_btn.Visible = false;
			}

		}

		private void update_btn_Click(object sender, EventArgs e)
		{
			UpdateUserDetails updateUserDetails = new UpdateUserDetails();
			updateUserDetails.Show();
			this.Close();
		}


		private void brows_btn_Click(object sender, EventArgs e)
		{
			Browse browse = new Browse();
			browse.Show();
			this.Hide();

		}
	}
}
