﻿namespace DataBaseProject
{
	partial class search
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label_30 = new Label();
			data_table = new TableLayoutPanel();
			isbn = new TextBox();
			label_5 = new Label();
			label_3 = new Label();
			label_2 = new Label();
			fees = new TextBox();
			author = new TextBox();
			title = new TextBox();
			tableLayoutPanel1 = new TableLayoutPanel();
			label1 = new Label();
			tableLayoutPanel2 = new TableLayoutPanel();
			textBox7 = new TextBox();
			textBox8 = new TextBox();
			textBox9 = new TextBox();
			textBox10 = new TextBox();
			textBox11 = new TextBox();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			textBox12 = new TextBox();
			tableLayoutPanel3 = new TableLayoutPanel();
			label8 = new Label();
			label9 = new Label();
			search_btn = new Button();
			tableLayoutPanel4 = new TableLayoutPanel();
			textBox1 = new TextBox();
			textBox2 = new TextBox();
			data_table.SuspendLayout();
			tableLayoutPanel1.SuspendLayout();
			tableLayoutPanel2.SuspendLayout();
			tableLayoutPanel4.SuspendLayout();
			SuspendLayout();
			// 
			// label_30
			// 
			label_30.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_30.AutoSize = true;
			label_30.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
			label_30.Location = new Point(3, 28);
			label_30.Name = "label_30";
			label_30.Size = new Size(109, 25);
			label_30.TabIndex = 1;
			label_30.Text = "Title";
			label_30.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// data_table
			// 
			data_table.AllowDrop = true;
			data_table.Anchor = AnchorStyles.None;
			data_table.AutoSize = true;
			data_table.ColumnCount = 2;
			data_table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.23656F));
			data_table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.76344F));
			data_table.Controls.Add(isbn, 1, 2);
			data_table.Controls.Add(label_5, 0, 3);
			data_table.Controls.Add(label_3, 0, 2);
			data_table.Controls.Add(label_2, 0, 1);
			data_table.Controls.Add(label_30, 0, 0);
			data_table.Controls.Add(fees, 1, 3);
			data_table.Controls.Add(author, 1, 1);
			data_table.Controls.Add(title, 1, 0);
			data_table.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			data_table.Location = new Point(28, 108);
			data_table.Name = "data_table";
			data_table.RowCount = 4;
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 24.9999962F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 24.9999962F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
			data_table.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			data_table.Size = new Size(439, 212);
			data_table.TabIndex = 11;
			// 
			// isbn
			// 
			isbn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			isbn.Location = new Point(118, 123);
			isbn.Name = "isbn";
			isbn.Size = new Size(318, 31);
			isbn.TabIndex = 12;
			// 
			// label_5
			// 
			label_5.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_5.AutoSize = true;
			label_5.Location = new Point(3, 187);
			label_5.Name = "label_5";
			label_5.Size = new Size(109, 25);
			label_5.TabIndex = 8;
			label_5.Text = "Fees";
			label_5.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label_3
			// 
			label_3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_3.AutoSize = true;
			label_3.Location = new Point(3, 132);
			label_3.Name = "label_3";
			label_3.Size = new Size(109, 25);
			label_3.TabIndex = 4;
			label_3.Text = "ISBN";
			label_3.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label_2
			// 
			label_2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label_2.AutoSize = true;
			label_2.Location = new Point(3, 80);
			label_2.Name = "label_2";
			label_2.Size = new Size(109, 25);
			label_2.TabIndex = 2;
			label_2.Text = "Author";
			label_2.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// fees
			// 
			fees.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			fees.Location = new Point(118, 178);
			fees.Name = "fees";
			fees.Size = new Size(318, 31);
			fees.TabIndex = 14;
			// 
			// author
			// 
			author.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			author.Location = new Point(118, 71);
			author.Name = "author";
			author.Size = new Size(318, 31);
			author.TabIndex = 11;
			// 
			// title
			// 
			title.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			title.Location = new Point(118, 19);
			title.Name = "title";
			title.Size = new Size(318, 31);
			title.TabIndex = 15;
			// 
			// tableLayoutPanel1
			// 
			tableLayoutPanel1.AllowDrop = true;
			tableLayoutPanel1.Anchor = AnchorStyles.None;
			tableLayoutPanel1.AutoSize = true;
			tableLayoutPanel1.ColumnCount = 1;
			tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48F));
			tableLayoutPanel1.Controls.Add(label1, 0, 0);
			tableLayoutPanel1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			tableLayoutPanel1.Location = new Point(28, 12);
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			tableLayoutPanel1.RowCount = 1;
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
			tableLayoutPanel1.Size = new Size(437, 62);
			tableLayoutPanel1.TabIndex = 12;
			// 
			// label1
			// 
			label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label1.AutoSize = true;
			label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label1.Location = new Point(3, 0);
			label1.Name = "label1";
			label1.Size = new Size(431, 62);
			label1.TabIndex = 1;
			label1.Text = "Search";
			label1.TextAlign = ContentAlignment.MiddleCenter;
			// 
			// tableLayoutPanel2
			// 
			tableLayoutPanel2.AllowDrop = true;
			tableLayoutPanel2.Anchor = AnchorStyles.None;
			tableLayoutPanel2.AutoSize = true;
			tableLayoutPanel2.ColumnCount = 2;
			tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.2365589F));
			tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.76344F));
			tableLayoutPanel2.Controls.Add(textBox7, 1, 5);
			tableLayoutPanel2.Controls.Add(textBox8, 1, 4);
			tableLayoutPanel2.Controls.Add(textBox9, 1, 3);
			tableLayoutPanel2.Controls.Add(textBox10, 1, 2);
			tableLayoutPanel2.Controls.Add(textBox11, 1, 1);
			tableLayoutPanel2.Controls.Add(label2, 0, 0);
			tableLayoutPanel2.Controls.Add(label3, 0, 5);
			tableLayoutPanel2.Controls.Add(label4, 0, 4);
			tableLayoutPanel2.Controls.Add(label5, 0, 3);
			tableLayoutPanel2.Controls.Add(label6, 0, 2);
			tableLayoutPanel2.Controls.Add(label7, 0, 1);
			tableLayoutPanel2.Controls.Add(textBox12, 1, 0);
			tableLayoutPanel2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			tableLayoutPanel2.Location = new Point(54, 192);
			tableLayoutPanel2.Name = "tableLayoutPanel2";
			tableLayoutPanel2.RowCount = 6;
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
			tableLayoutPanel2.Size = new Size(465, 332);
			tableLayoutPanel2.TabIndex = 11;
			// 
			// textBox7
			// 
			textBox7.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox7.Location = new Point(125, 298);
			textBox7.Name = "textBox7";
			textBox7.Size = new Size(337, 31);
			textBox7.TabIndex = 14;
			// 
			// textBox8
			// 
			textBox8.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox8.Location = new Point(125, 241);
			textBox8.Name = "textBox8";
			textBox8.Size = new Size(337, 31);
			textBox8.TabIndex = 13;
			// 
			// textBox9
			// 
			textBox9.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox9.Location = new Point(125, 186);
			textBox9.Name = "textBox9";
			textBox9.Size = new Size(337, 31);
			textBox9.TabIndex = 12;
			// 
			// textBox10
			// 
			textBox10.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox10.Location = new Point(125, 131);
			textBox10.Name = "textBox10";
			textBox10.Size = new Size(337, 31);
			textBox10.TabIndex = 11;
			// 
			// textBox11
			// 
			textBox11.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox11.Location = new Point(125, 76);
			textBox11.Name = "textBox11";
			textBox11.Size = new Size(337, 31);
			textBox11.TabIndex = 10;
			// 
			// label2
			// 
			label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label2.AutoSize = true;
			label2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
			label2.Location = new Point(3, 30);
			label2.Name = "label2";
			label2.Size = new Size(116, 25);
			label2.TabIndex = 1;
			label2.Text = "Title";
			label2.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			label3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label3.AutoSize = true;
			label3.Location = new Point(3, 307);
			label3.Name = "label3";
			label3.Size = new Size(116, 25);
			label3.TabIndex = 8;
			label3.Text = "Fees";
			label3.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			label4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label4.AutoSize = true;
			label4.Location = new Point(3, 250);
			label4.Name = "label4";
			label4.Size = new Size(116, 25);
			label4.TabIndex = 6;
			label4.Text = "Category id";
			label4.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			label5.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label5.AutoSize = true;
			label5.Location = new Point(3, 195);
			label5.Name = "label5";
			label5.Size = new Size(116, 25);
			label5.TabIndex = 4;
			label5.Text = "ISBN";
			label5.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label6
			// 
			label6.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label6.AutoSize = true;
			label6.Location = new Point(3, 140);
			label6.Name = "label6";
			label6.Size = new Size(116, 25);
			label6.TabIndex = 2;
			label6.Text = "Author";
			label6.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			label7.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label7.AutoSize = true;
			label7.Location = new Point(3, 85);
			label7.Name = "label7";
			label7.Size = new Size(116, 25);
			label7.TabIndex = 0;
			label7.Text = "ID";
			label7.TextAlign = ContentAlignment.MiddleLeft;
			// 
			// textBox12
			// 
			textBox12.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox12.Location = new Point(125, 21);
			textBox12.Name = "textBox12";
			textBox12.Size = new Size(337, 31);
			textBox12.TabIndex = 9;
			// 
			// tableLayoutPanel3
			// 
			tableLayoutPanel3.AllowDrop = true;
			tableLayoutPanel3.Anchor = AnchorStyles.None;
			tableLayoutPanel3.AutoSize = true;
			tableLayoutPanel3.ColumnCount = 1;
			tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48F));
			tableLayoutPanel3.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
			tableLayoutPanel3.Location = new Point(0, 0);
			tableLayoutPanel3.Name = "tableLayoutPanel3";
			tableLayoutPanel3.RowCount = 1;
			tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel3.Size = new Size(200, 100);
			tableLayoutPanel3.TabIndex = 0;
			// 
			// label8
			// 
			label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			label8.AutoSize = true;
			label8.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
			label8.Location = new Point(3, 0);
			label8.Name = "label8";
			label8.Size = new Size(194, 100);
			label8.TabIndex = 1;
			label8.TextAlign = ContentAlignment.BottomCenter;
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Font = new Font("Segoe UI", 8F, FontStyle.Bold, GraphicsUnit.Point);
			label9.ForeColor = Color.FromArgb(192, 0, 0);
			label9.Location = new Point(28, 380);
			label9.Name = "label9";
			label9.Size = new Size(321, 19);
			label9.TabIndex = 13;
			label9.Text = "Note: Fill the text box you want to search for it";
			// 
			// search_btn
			// 
			search_btn.Location = new Point(373, 374);
			search_btn.Name = "search_btn";
			search_btn.Size = new Size(94, 29);
			search_btn.TabIndex = 14;
			search_btn.Text = "Search";
			search_btn.UseVisualStyleBackColor = true;
			search_btn.Click += search_btn_Click;
			// 
			// tableLayoutPanel4
			// 
			tableLayoutPanel4.AllowDrop = true;
			tableLayoutPanel4.Anchor = AnchorStyles.None;
			tableLayoutPanel4.AutoSize = true;
			tableLayoutPanel4.ColumnCount = 2;
			tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.2365589F));
			tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.76344F));
			tableLayoutPanel4.Controls.Add(textBox1, 1, 5);
			tableLayoutPanel4.Location = new Point(0, 0);
			tableLayoutPanel4.Name = "tableLayoutPanel4";
			tableLayoutPanel4.RowCount = 6;
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
			tableLayoutPanel4.Size = new Size(200, 100);
			tableLayoutPanel4.TabIndex = 0;
			// 
			// textBox1
			// 
			textBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox1.Location = new Point(55, 103);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(142, 27);
			textBox1.TabIndex = 14;
			// 
			// textBox2
			// 
			textBox2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBox2.Location = new Point(55, 3);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(142, 27);
			textBox2.TabIndex = 13;
			// 
			// search
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(487, 417);
			Controls.Add(search_btn);
			Controls.Add(label9);
			Controls.Add(tableLayoutPanel1);
			Controls.Add(data_table);
			Name = "search";
			Text = "search";
			Load += search_Load;
			data_table.ResumeLayout(false);
			data_table.PerformLayout();
			tableLayoutPanel1.ResumeLayout(false);
			tableLayoutPanel1.PerformLayout();
			tableLayoutPanel2.ResumeLayout(false);
			tableLayoutPanel2.PerformLayout();
			tableLayoutPanel4.ResumeLayout(false);
			tableLayoutPanel4.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label_30;
		protected TableLayoutPanel data_table;
		private Label label_5;
		private Label label_3;
		private Label label_2;
		private TextBox fees;
		private TextBox isbn;
		private TextBox author;
		private TableLayoutPanel tableLayoutPanel1;
		private Label label1;
		protected TableLayoutPanel tableLayoutPanel2;
		private TextBox textBox7;
		private TextBox textBox8;
		private TextBox textBox9;
		private TextBox textBox10;
		private TextBox textBox11;
		private Label label2;
		private Label label3;
		private Label label4;
		private Label label5;
		private Label label6;
		private Label label7;
		private TextBox textBox12;
		private TableLayoutPanel tableLayoutPanel3;
		private Label label8;
		private Label label9;
		private Button search_btn;
		private TableLayoutPanel tableLayoutPanel4;
		private TextBox textBox1;
		private TextBox textBox2;
		private TextBox title;
	}
}