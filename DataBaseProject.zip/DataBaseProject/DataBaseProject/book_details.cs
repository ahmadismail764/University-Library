﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBaseProject
{
	public partial class book_details : Form
	{
		public book_details(Book book)
		{
			InitializeComponent();
			book_name.Text = book.name;
			Id.Text = "" + book.bookId;
			author.Text = book.author;
			ISBN.Text = book.ISBN;
			catId.Text = "" + book.categoryId;
			fees.Text = "" + book.borrowingFees;
		}

	}
}
