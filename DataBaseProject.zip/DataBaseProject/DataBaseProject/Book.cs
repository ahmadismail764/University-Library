﻿namespace DataBaseProject
{
	public class Book
	{
		public int bookId;
		public String name;
		public String author;
		public String ISBN;
		public int categoryId;
		public int borrowingFees;
		public Book(int id, String bookName, String author, String isbn, int catID, int fees)
		{
			this.bookId = id;
			this.name = bookName;
			this.author = author;
			this.ISBN = isbn;
			this.categoryId = catID;
			this.borrowingFees = fees;
		}
	}
}
