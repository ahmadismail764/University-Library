﻿using System.Data.SqlClient;
using System.Net;
using DataBaseProject;
using static System.Reflection.Metadata.BlobBuilder;

namespace DataBaseProject
{
	public partial class Browse : Form
	{
		public Browse()
		{
			connection = MySqlConnection.MySqlConnection.Conn();
			InitializeComponent();
			view_book.Enabled = false;
			update_book.Enabled = false;
		}
		public SqlConnection connection;
		private bool isAdmin = GlobalVariables.isAdmin;
		Book selectedBook;
		List<Book> books = new List<Book>();
		static List<Book> static_books = new List<Book>();
		private void Browse_Books_Load(object sender, EventArgs e)
		{
			books = GetBooksFromDatabase();
			if (books.Count() > 0)
			{
				MessageBox.Show("Items Retrieved: " + books.Count());
			}
			if (isAdmin)
			{
				update_book.Visible = true;
			}
			else
			{
				update_book.Visible = false;
			}// Get books from database
			foreach (Book book in books)
			{
				ListViewItem item = new ListViewItem((books.IndexOf(book) + 1).ToString());
				item.SubItems.Add(book.name);
				item.SubItems.Add(book.author);
				listView1.Items.Add(item);
			}
		}

		public void ChangeLocalList()
		{
			books = GlobalVariables.books;
		}

		private void listView1_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (listView1.SelectedItems.Count > 0)
			{
				ListViewItem selectedItem = listView1.SelectedItems[0];
				string selectedBookName = selectedItem.SubItems[1].Text;  // Get the book name
				view_book.Enabled = true; // Enable button when an item is selected
				update_book.Enabled = true;

				foreach (Book book in books)
				{
					if (book.name == selectedBookName) { selectedBook = book; }
				}
			}
			else
			{
				update_book.Enabled = false;

				view_book.Enabled = false; // Disable button when no item is selected
			}
		}

		private List<Book> GetBooksFromDatabase()
		{
			List<Book> books = new List<Book>();
			using (connection)
			{
				connection.Open();

				string sql = "SELECT * FROM Book"; // Adjust SQL query based on your table and columns

				SqlCommand command = new SqlCommand(sql, connection);
				using (SqlDataReader reader = command.ExecuteReader())
				{
					while (reader.Read())
					{
						int bookid = reader.GetInt32(0);
						String name = reader.GetString(1);
						String author = reader.GetString(2);
						String isbn = reader.GetString(3);
						int catid = reader.GetInt32(4);
						int fees = reader.GetInt32(5);
						books.Add(new Book(bookid, name, author, isbn, catid, fees));
					}
				}
			}
			return books;
		}

		private void view_book_Click(object sender, EventArgs e)
		{
			book_details details = new book_details(selectedBook);
			details.Show();
		}

		private void update_book_Click(object sender, EventArgs e)
		{

		}

		private void label2_Click(object sender, EventArgs e)
		{
			Home home = new Home();
			home.Show();
			this.Hide();
		}

		private void search_btn_Click(object sender, EventArgs e)
		{
			search search_books = new search(books);
			search_books.Show();
		}
	}
}
