﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBaseProject
{
	public partial class search_res : Form
	{
		public search_res()
		{
			InitializeComponent();
		}

		List<Book> books = new List<Book>();
		private void search_res_Load(object sender, EventArgs e)
		{
			foreach (Book book in books)
			{
				ListViewItem item = new ListViewItem((books.IndexOf(book) + 1).ToString());
				item.SubItems.Add(book.name);
				item.SubItems.Add(book.author);
				listView1.Items.Add(item);
			}
		}
		public void update_list(List<Book> books)
		{
			listView1.Items.Clear();
			foreach (Book book in books)
			{
				ListViewItem item = new ListViewItem((books.IndexOf(book) + 1).ToString());
				item.SubItems.Add(book.name);
				item.SubItems.Add(book.author);
				listView1.Items.Add(item);
			}
		}
	}
}
