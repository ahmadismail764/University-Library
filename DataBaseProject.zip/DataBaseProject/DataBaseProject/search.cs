﻿using DataBaseProject;

namespace DataBaseProject
{
	public partial class search : Form
	{
		public search(List<Book> list)
		{
			InitializeComponent();
			books = list;
		}

		List<Book> books;
		private String bookTitle = null;
		private String bookISBN = null;
		private String bookAuthor = null;
		private int bookFees = 0;
		search_res res = new search_res();

		private void search_btn_Click(object sender, EventArgs e)
		{
			//if (id.Text.Length > 0) bookId = id.Text;
			if (title.Text.Length > 0) bookTitle = title.Text;
			if (author.Text.Length > 0) bookAuthor = author.Text;
			if (isbn.Text.Length > 0) bookISBN = isbn.Text;
			//if (catId.Text.Length > 0) categoryId = catId.Text;
			if (fees.Text.Length > 0) bookFees = Convert.ToInt32(fees.Text);

			List<Book> filtered_books = new List<Book>();

			foreach (Book book in books)
			{
				if (bookAuthor == null && bookTitle == null && bookISBN == null && bookFees == 0)
				{
					filtered_books = books;
				}
				if (bookAuthor != null)
				{
					if (book.author.Contains(bookAuthor))
					{
						filtered_books.Add(book);
					}
				}
				if (bookTitle != null)
				{
					if (book.name.Contains(bookTitle))
					{
						filtered_books.Add(book);
					}
				}
				if (bookISBN != null)
				{
					if (book.ISBN.Contains(bookISBN))
					{
						filtered_books.Add(book);
					}
				}
				if (bookFees == 0)
				{
					filtered_books.Add(book);
				}
			}
			for (int i = 0; i < filtered_books.Count(); i++)
			{
				for (int j = i + 1; j < filtered_books.Count(); j++)
				{
					if (filtered_books[i] == filtered_books[j])
					{
						filtered_books.RemoveAt(j);
					}
				}
			}
			res.update_list(filtered_books);
			bookISBN = null;
			bookAuthor = null;
			bookFees = 0;
			bookTitle = null;
		}

		private void search_Load(object sender, EventArgs e)
		{
			res.Show();
		}
	}
}