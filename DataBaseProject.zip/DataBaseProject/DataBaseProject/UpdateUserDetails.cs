﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBaseProject
{
	public partial class UpdateUserDetails : Form
	{
		int userId = GlobalVariables.currentUserId;
		bool isAdmin = GlobalVariables.isAdmin;
		public UpdateUserDetails()
		{
			InitializeComponent();
			LoadUserDetails();
		}

		SqlConnection connection = MySqlConnection.MySqlConnection.Conn();

		private void LoadUserDetails()
		{
			try
			{
				//int userId = GlobalVariables.currentUserId;

				// Construct the SELECT query to fetch user details based on the user ID
				string selectQuery = isAdmin ? "SELECT * FROM Admin WHERE id = @userId" : "SELECT * FROM Student WHERE id = @userId";

				// Create a SqlCommand object with the SELECT query and connection
				using (SqlCommand command = new SqlCommand(selectQuery, connection))
				{
					// Add parameters to the command to prevent SQL injection
					command.Parameters.AddWithValue("@userId", userId);

					// Open the connection and execute the SELECT query
					connection.Open();
					SqlDataReader reader = command.ExecuteReader();

					if (reader.Read())  // If user details are found
					{
						// Populate the text boxes with user details
						username_txt.Text = reader["Username"].ToString();
						email_txt.Text = reader["Email"].ToString();
						password_txt.Text = reader["Password"].ToString();
						phone_txt.Text = reader["Phone"].ToString();
						address_txt.Text = reader["Address"].ToString();
					}
					else  // If user details are not found
					{
						MessageBox.Show("User details not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}

					reader.Close();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				connection.Close();
			}
		}

		private void update_btn_Click(object sender, EventArgs e)
		{
			// Get the new user details from the text boxes
			string newUsername = username_txt.Text;
			string newPassword = password_txt.Text;
			string newEmail = email_txt.Text;
			string newPhone = phone_txt.Text;
			string newAddress = address_txt.Text;

			try
			{
				// Construct the update query with parameters
				string updateQuery = isAdmin ? "UPDATE Admin SET username = @newUsername, password = @newPassword, email = @newEmail, phone = @newPhone, address = @newAddress WHERE id = @userId" :
											"UPDATE Student SET username = @newUsername, password = @newPassword, email = @newEmail, phone = @newPhone, address = @newAddress WHERE id = @userId";

				using (SqlCommand command = new SqlCommand(updateQuery, connection))
				{
					// Add parameters to the command
					command.Parameters.AddWithValue("@newUsername", newUsername);
					command.Parameters.AddWithValue("@newPassword", newPassword);
					command.Parameters.AddWithValue("@newEmail", newEmail);
					command.Parameters.AddWithValue("@newPhone", newPhone);
					command.Parameters.AddWithValue("@newAddress", newAddress);
					command.Parameters.AddWithValue("@userId", userId);

					// Open the connection and execute the update query
					connection.Open();
					int rowsAffected = command.ExecuteNonQuery();

					if (rowsAffected > 0)
					{
						MessageBox.Show("User details updated successfully");

						Home home = new Home();
						home.Show();
						this.Close();
					}
					else
					{
						MessageBox.Show("No rows updated. User not found or no changes made.");
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error updating user details: " + ex.Message);
			}
			finally
			{
				connection.Close();
			}
		}

	}

}
